"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  Search,
  Filter,
  MoreVertical,
  Eye,
  Mail,
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle,
  AlertTriangle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"

const students = [
  {
    id: 1,
    name: "Ahmed Khan",
    email: "ahmed.k@school.edu.pk",
    completed: 8,
    total: 10,
    avgScore: 85,
    trend: "up",
    lastActive: "2 hours ago",
    pendingReview: true,
    hazardIncidents: 1,
  },
  {
    id: 2,
    name: "Sara Malik",
    email: "sara.m@school.edu.pk",
    completed: 10,
    total: 10,
    avgScore: 92,
    trend: "up",
    lastActive: "1 hour ago",
    pendingReview: false,
    hazardIncidents: 0,
  },
  {
    id: 3,
    name: "Hassan Ali",
    email: "hassan.a@school.edu.pk",
    completed: 5,
    total: 10,
    avgScore: 68,
    trend: "down",
    lastActive: "3 days ago",
    pendingReview: true,
    hazardIncidents: 3,
  },
  {
    id: 4,
    name: "Fatima Zahra",
    email: "fatima.z@school.edu.pk",
    completed: 9,
    total: 10,
    avgScore: 88,
    trend: "up",
    lastActive: "30 min ago",
    pendingReview: false,
    hazardIncidents: 0,
  },
  {
    id: 5,
    name: "Usman Tariq",
    email: "usman.t@school.edu.pk",
    completed: 7,
    total: 10,
    avgScore: 75,
    trend: "stable",
    lastActive: "1 day ago",
    pendingReview: true,
    hazardIncidents: 2,
  },
]

export default function ClassDetailPage() {
  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const filteredStudents = students.filter((student) => {
    const matchesSearch = student.name.toLowerCase().includes(search.toLowerCase())
    const matchesStatus =
      statusFilter === "all" ||
      (statusFilter === "pending" && student.pendingReview) ||
      (statusFilter === "completed" && student.completed === student.total) ||
      (statusFilter === "at-risk" && student.avgScore < 70)
    return matchesSearch && matchesStatus
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/teacher/classes">
            <ArrowLeft className="w-5 h-5" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold">Class 9-A</h1>
          <p className="text-muted-foreground">Physics - 32 Students</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="rounded-xl border border-border bg-card/50 backdrop-blur-sm p-4">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <CheckCircle className="w-4 h-4" />
            <span className="text-sm">Completion</span>
          </div>
          <p className="text-2xl font-bold">78%</p>
          <Progress value={78} className="h-1.5 mt-2" />
        </div>
        <div className="rounded-xl border border-border bg-card/50 backdrop-blur-sm p-4">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <TrendingUp className="w-4 h-4" />
            <span className="text-sm">Avg Score</span>
          </div>
          <p className="text-2xl font-bold text-green-400">82%</p>
        </div>
        <div className="rounded-xl border border-border bg-card/50 backdrop-blur-sm p-4">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <Clock className="w-4 h-4" />
            <span className="text-sm">Pending</span>
          </div>
          <p className="text-2xl font-bold text-orange-400">5</p>
        </div>
        <div className="rounded-xl border border-border bg-card/50 backdrop-blur-sm p-4">
          <div className="flex items-center gap-2 text-muted-foreground mb-2">
            <AlertTriangle className="w-4 h-4" />
            <span className="text-sm">At Risk</span>
          </div>
          <p className="text-2xl font-bold text-red-400">3</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search students..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-card border-border"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[180px] bg-card border-border">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Filter" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Students</SelectItem>
            <SelectItem value="pending">Pending Review</SelectItem>
            <SelectItem value="completed">Completed All</SelectItem>
            <SelectItem value="at-risk">At Risk</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border border-border bg-card/50 backdrop-blur-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                <th className="text-left p-4 font-medium text-muted-foreground">Student</th>
                <th className="text-left p-4 font-medium text-muted-foreground">Progress</th>
                <th className="text-left p-4 font-medium text-muted-foreground hidden md:table-cell">Avg Score</th>
                <th className="text-left p-4 font-medium text-muted-foreground hidden lg:table-cell">Last Active</th>
                <th className="text-left p-4 font-medium text-muted-foreground">Status</th>
                <th className="text-right p-4 font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredStudents.map((student, index) => (
                <motion.tr
                  key={student.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-border/50 hover:bg-muted/20 transition-colors"
                >
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {student.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{student.name}</p>
                        <p className="text-sm text-muted-foreground">{student.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <Progress value={(student.completed / student.total) * 100} className="w-20 h-2" />
                      <span className="text-sm">
                        {student.completed}/{student.total}
                      </span>
                    </div>
                  </td>
                  <td className="p-4 hidden md:table-cell">
                    <div className="flex items-center gap-2">
                      <span
                        className={`font-medium ${
                          student.avgScore >= 80
                            ? "text-green-400"
                            : student.avgScore >= 70
                              ? "text-yellow-400"
                              : "text-red-400"
                        }`}
                      >
                        {student.avgScore}%
                      </span>
                      {student.trend === "up" && <TrendingUp className="w-4 h-4 text-green-400" />}
                      {student.trend === "down" && <TrendingDown className="w-4 h-4 text-red-400" />}
                    </div>
                  </td>
                  <td className="p-4 hidden lg:table-cell text-sm text-muted-foreground">{student.lastActive}</td>
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      {student.pendingReview && (
                        <Badge className="bg-orange-500/20 text-orange-400 border-orange-500/30">Review</Badge>
                      )}
                      {student.hazardIncidents > 0 && (
                        <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                          {student.hazardIncidents} Hazards
                        </Badge>
                      )}
                      {!student.pendingReview && student.hazardIncidents === 0 && (
                        <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Good</Badge>
                      )}
                    </div>
                  </td>
                  <td className="p-4 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Eye className="w-4 h-4 mr-2" />
                          View Progress
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Clock className="w-4 h-4 mr-2" />
                          Review Attempts
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Mail className="w-4 h-4 mr-2" />
                          Send Message
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
