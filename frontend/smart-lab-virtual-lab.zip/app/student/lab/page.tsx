import { redirect } from "next/navigation"

export default function LabIndexPage() {
  redirect("/student/dashboard")
}
