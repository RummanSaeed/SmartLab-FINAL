"use client"

import { use, useState } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import {
  ArrowLeft,
  Play,
  Pause,
  RotateCcw,
  Save,
  ChevronRight,
  ChevronLeft,
  AlertTriangle,
  Activity,
  Zap,
  Maximize,
  Info,
  FileText,
  CheckCircle,
  X,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LabCanvas } from "@/components/lab/canvas"
import { EquipmentDrawer } from "@/components/lab/equipment-drawer"
import { AITutorPanel } from "@/components/lab/ai-tutor-panel"
import { LiveReadings } from "@/components/lab/live-readings"
import { SafetyOverlay } from "@/components/lab/safety-overlay"

export default function LabWorkspace({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = use(params)
  const [isRunning, setIsRunning] = useState(false)
  const [leftPanelOpen, setLeftPanelOpen] = useState(true)
  const [rightPanelOpen, setRightPanelOpen] = useState(true)
  const [showSafetyWarning, setShowSafetyWarning] = useState(false)
  const [mode, setMode] = useState<"hazard" | "grading">("hazard")
  const [showSaveModal, setShowSaveModal] = useState(false)

  // Equipment parameters
  const [voltage, setVoltage] = useState([5])
  const [resistance, setResistance] = useState([100])

  const handleRun = () => {
    // Simulate hazard detection
    if (voltage[0] > 12 && mode === "hazard") {
      setShowSafetyWarning(true)
    } else {
      setIsRunning(true)
      setTimeout(() => setIsRunning(false), 3000)
    }
  }

  const handleProceed = () => {
    setShowSafetyWarning(false)
    setIsRunning(true)
    setTimeout(() => setIsRunning(false), 3000)
  }

  const handleSaveAttempt = () => {
    setShowSaveModal(true)
  }

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="h-16 border-b border-border/50 bg-card/50 backdrop-blur flex items-center justify-between px-4 z-10">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/student/dashboard">
              <ArrowLeft className="w-5 h-5" />
            </Link>
          </Button>
          <div>
            <h1 className="text-lg font-bold">Ohm's Law Verification</h1>
            <p className="text-sm text-muted-foreground">Physics • Class 10 • Medium</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Mode Toggle */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-background border border-border">
            <button
              onClick={() => setMode("hazard")}
              className={`px-3 py-1 rounded text-sm transition-colors ${
                mode === "hazard"
                  ? "bg-secondary text-secondary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Hazard Mode
            </button>
            <button
              onClick={() => setMode("grading")}
              className={`px-3 py-1 rounded text-sm transition-colors ${
                mode === "grading"
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              Grading Mode
            </button>
          </div>

          {/* Controls */}
          <Button onClick={handleRun} disabled={isRunning} className="gap-2">
            {isRunning ? (
              <>
                <Pause className="w-4 h-4" />
                Running...
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Run Simulation
              </>
            )}
          </Button>
          <Button variant="outline" onClick={() => {}}>
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
          <Button variant="outline" onClick={handleSaveAttempt}>
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Panel - Equipment */}
        <AnimatePresence mode="wait">
          {leftPanelOpen && (
            <motion.aside
              initial={{ x: -300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -300, opacity: 0 }}
              className="w-80 border-r border-border/50 bg-card/30 backdrop-blur flex flex-col"
            >
              <div className="p-4 border-b border-border/50 flex items-center justify-between">
                <h2 className="font-semibold">Equipment & Controls</h2>
                <Button variant="ghost" size="icon" onClick={() => setLeftPanelOpen(false)}>
                  <ChevronLeft className="w-5 h-5" />
                </Button>
              </div>

              <Tabs defaultValue="equipment" className="flex-1 flex flex-col">
                <TabsList className="mx-4 mt-2">
                  <TabsTrigger value="equipment" className="flex-1">
                    Equipment
                  </TabsTrigger>
                  <TabsTrigger value="parameters" className="flex-1">
                    Parameters
                  </TabsTrigger>
                  <TabsTrigger value="saved" className="flex-1">
                    Saved
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="equipment" className="flex-1 overflow-auto p-4">
                  <EquipmentDrawer />
                </TabsContent>

                <TabsContent value="parameters" className="flex-1 overflow-auto p-4 space-y-6">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">Voltage (V)</label>
                      <span className="text-sm text-muted-foreground">{voltage[0]}V</span>
                    </div>
                    <Slider value={voltage} onValueChange={setVoltage} min={0} max={20} step={0.5} className="w-full" />
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">Resistance (Ω)</label>
                      <span className="text-sm text-muted-foreground">{resistance[0]}Ω</span>
                    </div>
                    <Slider
                      value={resistance}
                      onValueChange={setResistance}
                      min={10}
                      max={500}
                      step={10}
                      className="w-full"
                    />
                  </div>

                  <div className="pt-4 border-t border-border/50">
                    <h3 className="text-sm font-medium mb-3">Calculated Values</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Current (I)</span>
                        <span className="font-medium">{(voltage[0] / resistance[0]).toFixed(3)} A</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Power (P)</span>
                        <span className="font-medium">{((voltage[0] * voltage[0]) / resistance[0]).toFixed(3)} W</span>
                      </div>
                    </div>
                  </div>

                  {voltage[0] > 12 && (
                    <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30 flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-500 mt-0.5" />
                      <div className="text-sm">
                        <p className="font-medium text-yellow-500">Warning</p>
                        <p className="text-muted-foreground">High voltage detected. Proceed with caution.</p>
                      </div>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="saved" className="flex-1 overflow-auto p-4">
                  <div className="text-center text-muted-foreground py-8">
                    <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p className="text-sm">No saved setups yet</p>
                    <Button variant="link" size="sm" className="mt-2">
                      Save current setup
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Center Panel - Lab Canvas */}
        <div className="flex-1 flex flex-col relative">
          {/* Toggle Left Panel Button */}
          {!leftPanelOpen && (
            <Button
              variant="outline"
              size="icon"
              onClick={() => setLeftPanelOpen(true)}
              className="absolute top-4 left-4 z-10"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          )}

          {/* Toggle Right Panel Button */}
          {!rightPanelOpen && (
            <Button
              variant="outline"
              size="icon"
              onClick={() => setRightPanelOpen(true)}
              className="absolute top-4 right-4 z-10"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
          )}

          {/* Status Bar */}
          <div className="p-3 border-b border-border/50 bg-card/30 backdrop-blur flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Badge variant={isRunning ? "default" : "outline"} className="gap-1">
                <Activity className="w-3 h-3" />
                {isRunning ? "Simulation Running" : "Ready"}
              </Badge>
              <Badge variant="outline" className="gap-1">
                <Zap className="w-3 h-3" />
                {mode === "hazard" ? "Hazard Detection ON" : "Grading Mode"}
              </Badge>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>Camera Controls:</span>
              <kbd className="px-2 py-0.5 rounded bg-muted text-xs">Mouse Drag</kbd>
              <kbd className="px-2 py-0.5 rounded bg-muted text-xs">Scroll</kbd>
            </div>
          </div>

          {/* Canvas */}
          <div className="flex-1 relative bg-gradient-to-b from-background to-muted/20">
            <LabCanvas voltage={voltage[0]} resistance={resistance[0]} isRunning={isRunning} />

            {/* Overlay Info */}
            <div className="absolute bottom-4 left-4 flex flex-col gap-2">
              <Button variant="outline" size="sm" className="bg-background/80 backdrop-blur">
                <Info className="w-4 h-4 mr-2" />
                View Theory
              </Button>
              <Button variant="outline" size="sm" className="bg-background/80 backdrop-blur">
                <Maximize className="w-4 h-4 mr-2" />
                Fullscreen
              </Button>
            </div>
          </div>
        </div>

        {/* Right Panel - AI Tutor & Readings */}
        <AnimatePresence mode="wait">
          {rightPanelOpen && (
            <motion.aside
              initial={{ x: 300, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 300, opacity: 0 }}
              className="w-96 border-l border-border/50 bg-card/30 backdrop-blur flex flex-col"
            >
              <div className="p-4 border-b border-border/50 flex items-center justify-between">
                <h2 className="font-semibold">Assistant & Data</h2>
                <Button variant="ghost" size="icon" onClick={() => setRightPanelOpen(false)}>
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </div>

              <Tabs defaultValue="tutor" className="flex-1 flex flex-col">
                <TabsList className="mx-4 mt-2">
                  <TabsTrigger value="tutor" className="flex-1">
                    AI Tutor
                  </TabsTrigger>
                  <TabsTrigger value="readings" className="flex-1">
                    Readings
                  </TabsTrigger>
                  <TabsTrigger value="warnings" className="flex-1">
                    Warnings
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="tutor" className="flex-1 overflow-hidden">
                  <AITutorPanel experimentId={id} />
                </TabsContent>

                <TabsContent value="readings" className="flex-1 overflow-auto p-4">
                  <LiveReadings voltage={voltage[0]} resistance={resistance[0]} isRunning={isRunning} />
                </TabsContent>

                <TabsContent value="warnings" className="flex-1 overflow-auto p-4">
                  <div className="space-y-3">
                    {voltage[0] > 15 && (
                      <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30">
                        <div className="flex items-start gap-2 mb-2">
                          <AlertTriangle className="w-4 h-4 text-red-500 mt-0.5" />
                          <div>
                            <p className="font-medium text-red-500 text-sm">Critical Voltage</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              Voltage exceeds safe limits. Risk of component damage.
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                    {voltage[0] > 12 && voltage[0] <= 15 && (
                      <div className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                        <div className="flex items-start gap-2">
                          <AlertTriangle className="w-4 h-4 text-yellow-500 mt-0.5" />
                          <div>
                            <p className="font-medium text-yellow-500 text-sm">High Voltage Warning</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              Voltage is above recommended range. Monitor carefully.
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                    {voltage[0] <= 12 && (
                      <div className="text-center text-muted-foreground py-8">
                        <CheckCircle className="w-12 h-12 mx-auto mb-3 opacity-50" />
                        <p className="text-sm">No warnings</p>
                        <p className="text-xs mt-1">All parameters are within safe limits</p>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </Tabs>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>

      {/* Safety Warning Overlay */}
      <AnimatePresence>
        {showSafetyWarning && <SafetyOverlay onCancel={() => setShowSafetyWarning(false)} onProceed={handleProceed} />}
      </AnimatePresence>

      {/* Save Attempt Modal */}
      <AnimatePresence>
        {showSaveModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowSaveModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-card border border-border rounded-2xl p-6 max-w-md w-full"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold">Save Attempt</h3>
                <Button variant="ghost" size="icon" onClick={() => setShowSaveModal(false)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>
              <p className="text-muted-foreground mb-4">
                Add notes about this experiment attempt for future reference.
              </p>
              <textarea
                placeholder="What did you learn? Any observations?"
                className="w-full h-32 px-3 py-2 rounded-lg bg-background border border-border resize-none focus:outline-none focus:ring-2 focus:ring-primary mb-4"
              />
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1 bg-transparent" onClick={() => setShowSaveModal(false)}>
                  Cancel
                </Button>
                <Button className="flex-1">
                  <Save className="w-4 h-4 mr-2" />
                  Save Attempt
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
