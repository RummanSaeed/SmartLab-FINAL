"use client"

import { useState } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import {
  Calendar,
  Clock,
  Search,
  ChevronRight,
  CheckCircle,
  AlertTriangle,
  Play,
  FileText,
  Download,
  MessageSquare,
  BarChart3,
  X,
  Eye,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { StudentSidebar } from "@/components/student/sidebar"

const attempts = [
  {
    id: 1,
    experiment: "Ohm's Law Verification",
    subject: "Physics",
    date: "Nov 24, 2025",
    time: "2:30 PM",
    duration: "45 min",
    score: 92,
    status: "completed",
    hazardIncidents: 0,
    aiConversations: 5,
    configuration: {
      voltage: 12,
      resistance: 100,
    },
    feedback: "Excellent work! Your understanding of the relationship between voltage and current is clear.",
  },
  {
    id: 2,
    experiment: "Acid-Base Titration",
    subject: "Chemistry",
    date: "Nov 23, 2025",
    time: "11:00 AM",
    duration: "52 min",
    score: 78,
    status: "completed",
    hazardIncidents: 1,
    aiConversations: 8,
    configuration: {
      acidConcentration: 0.1,
      volume: 25,
    },
    feedback: "Good attempt. Work on your endpoint detection - you went slightly past the equivalence point.",
  },
  {
    id: 3,
    experiment: "Simple Pendulum",
    subject: "Physics",
    date: "Nov 22, 2025",
    time: "3:15 PM",
    duration: "30 min",
    score: 95,
    status: "completed",
    hazardIncidents: 0,
    aiConversations: 3,
    configuration: {
      length: 0.5,
      mass: 0.2,
    },
    feedback: "Perfect execution! Your measurements were precise and calculations accurate.",
  },
  {
    id: 4,
    experiment: "Resistors in Series",
    subject: "Physics",
    date: "Nov 21, 2025",
    time: "10:45 AM",
    duration: "25 min",
    score: null,
    status: "in-progress",
    hazardIncidents: 2,
    aiConversations: 4,
    configuration: {
      r1: 50,
      r2: 100,
      r3: 150,
    },
    feedback: null,
  },
  {
    id: 5,
    experiment: "Salt Analysis",
    subject: "Chemistry",
    date: "Nov 20, 2025",
    time: "1:00 PM",
    duration: "55 min",
    score: 85,
    status: "completed",
    hazardIncidents: 0,
    aiConversations: 6,
    configuration: {
      salt: "CuSO4",
      tests: ["flame", "borax bead"],
    },
    feedback: "Good identification skills. Remember to always perform confirmatory tests.",
  },
]

export default function StudentHistoryPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedAttempt, setSelectedAttempt] = useState<(typeof attempts)[0] | null>(null)
  const [statusFilter, setStatusFilter] = useState("all")

  const filteredAttempts = attempts.filter((attempt) => {
    const matchesSearch = attempt.experiment.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesStatus = statusFilter === "all" || attempt.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const totalExperiments = attempts.length
  const completedExperiments = attempts.filter((a) => a.status === "completed").length
  const averageScore =
    attempts.filter((a) => a.score).reduce((acc, a) => acc + (a.score || 0), 0) / completedExperiments

  return (
    <div className="flex min-h-screen bg-background">
      <StudentSidebar />

      <main className="flex-1 p-6 lg:p-8 overflow-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">My History</h1>
          <p className="text-muted-foreground">Track your experiment attempts and progress over time.</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-card/50 backdrop-blur border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-primary/10">
                  <BarChart3 className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{totalExperiments}</p>
                  <p className="text-sm text-muted-foreground">Total Attempts</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card/50 backdrop-blur border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-green-500/10">
                  <CheckCircle className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{completedExperiments}</p>
                  <p className="text-sm text-muted-foreground">Completed</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card/50 backdrop-blur border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-secondary/10">
                  <BarChart3 className="w-6 h-6 text-secondary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{averageScore.toFixed(0)}%</p>
                  <p className="text-sm text-muted-foreground">Average Score</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card/50 backdrop-blur border-border/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-xl bg-yellow-500/10">
                  <AlertTriangle className="w-6 h-6 text-yellow-500" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{attempts.reduce((acc, a) => acc + a.hazardIncidents, 0)}</p>
                  <p className="text-sm text-muted-foreground">Hazard Incidents</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search experiments..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-card/50 border-border/50"
            />
          </div>
          <div className="flex gap-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2 rounded-lg bg-card/50 border border-border/50 text-sm"
            >
              <option value="all">All Status</option>
              <option value="completed">Completed</option>
              <option value="in-progress">In Progress</option>
            </select>
          </div>
        </div>

        {/* Attempts Timeline */}
        <div className="space-y-4">
          {filteredAttempts.map((attempt, index) => (
            <motion.div
              key={attempt.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card
                className="bg-card/50 backdrop-blur border-border/50 hover:border-primary/50 transition-colors cursor-pointer"
                onClick={() => setSelectedAttempt(attempt)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 flex-1">
                      <div
                        className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                          attempt.status === "completed"
                            ? attempt.score && attempt.score >= 80
                              ? "bg-green-500/10"
                              : "bg-yellow-500/10"
                            : "bg-primary/10"
                        }`}
                      >
                        {attempt.status === "completed" ? (
                          <CheckCircle
                            className={`w-6 h-6 ${
                              attempt.score && attempt.score >= 80 ? "text-green-500" : "text-yellow-500"
                            }`}
                          />
                        ) : (
                          <Play className="w-6 h-6 text-primary" />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold">{attempt.experiment}</h3>
                          <Badge variant="outline">{attempt.subject}</Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {attempt.date}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {attempt.duration}
                          </span>
                          <span className="flex items-center gap-1">
                            <MessageSquare className="w-4 h-4" />
                            {attempt.aiConversations} AI chats
                          </span>
                          {attempt.hazardIncidents > 0 && (
                            <span className="flex items-center gap-1 text-yellow-500">
                              <AlertTriangle className="w-4 h-4" />
                              {attempt.hazardIncidents} hazards
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {attempt.score !== null ? (
                        <div className="text-right">
                          <p
                            className={`text-2xl font-bold ${
                              attempt.score >= 80 ? "text-green-500" : "text-yellow-500"
                            }`}
                          >
                            {attempt.score}%
                          </p>
                          <p className="text-xs text-muted-foreground">Score</p>
                        </div>
                      ) : (
                        <Badge>In Progress</Badge>
                      )}
                      <ChevronRight className="w-5 h-5 text-muted-foreground" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Attempt Detail Modal */}
        {selectedAttempt && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedAttempt(null)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-card border border-border rounded-2xl p-6 max-w-2xl w-full max-h-[90vh] overflow-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold">{selectedAttempt.experiment}</h2>
                  <p className="text-muted-foreground">
                    {selectedAttempt.date} at {selectedAttempt.time}
                  </p>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setSelectedAttempt(null)}>
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <Tabs defaultValue="overview">
                <TabsList className="mb-4">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="configuration">Configuration</TabsTrigger>
                  <TabsTrigger value="feedback">Feedback</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="bg-background/50 border-border/50">
                      <CardContent className="p-4 text-center">
                        <p
                          className={`text-4xl font-bold ${
                            selectedAttempt.score && selectedAttempt.score >= 80
                              ? "text-green-500"
                              : selectedAttempt.score
                                ? "text-yellow-500"
                                : "text-muted-foreground"
                          }`}
                        >
                          {selectedAttempt.score ?? "--"}%
                        </p>
                        <p className="text-sm text-muted-foreground">Score</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-background/50 border-border/50">
                      <CardContent className="p-4 text-center">
                        <p className="text-4xl font-bold">{selectedAttempt.duration}</p>
                        <p className="text-sm text-muted-foreground">Duration</p>
                      </CardContent>
                    </Card>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <Card className="bg-background/50 border-border/50">
                      <CardContent className="p-4 flex items-center gap-3">
                        <MessageSquare className="w-5 h-5 text-primary" />
                        <div>
                          <p className="font-bold">{selectedAttempt.aiConversations}</p>
                          <p className="text-xs text-muted-foreground">AI Conversations</p>
                        </div>
                      </CardContent>
                    </Card>
                    <Card className="bg-background/50 border-border/50">
                      <CardContent className="p-4 flex items-center gap-3">
                        <AlertTriangle
                          className={`w-5 h-5 ${selectedAttempt.hazardIncidents > 0 ? "text-yellow-500" : "text-green-500"}`}
                        />
                        <div>
                          <p className="font-bold">{selectedAttempt.hazardIncidents}</p>
                          <p className="text-xs text-muted-foreground">Hazard Incidents</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="configuration">
                  <Card className="bg-background/50 border-border/50">
                    <CardContent className="p-4">
                      <h4 className="font-semibold mb-3">Experiment Setup</h4>
                      <div className="space-y-2">
                        {Object.entries(selectedAttempt.configuration).map(([key, value]) => (
                          <div key={key} className="flex justify-between py-2 border-b border-border/50 last:border-0">
                            <span className="text-muted-foreground capitalize">
                              {key.replace(/([A-Z])/g, " $1").trim()}
                            </span>
                            <span className="font-medium">
                              {Array.isArray(value) ? value.join(", ") : String(value)}
                            </span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="feedback">
                  {selectedAttempt.feedback ? (
                    <Card className="bg-background/50 border-border/50">
                      <CardContent className="p-4">
                        <h4 className="font-semibold mb-3">Teacher Feedback</h4>
                        <p className="text-muted-foreground">{selectedAttempt.feedback}</p>
                      </CardContent>
                    </Card>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No feedback yet</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>

              <div className="flex gap-3 mt-6">
                <Button variant="outline" className="flex-1 bg-transparent">
                  <Download className="w-4 h-4 mr-2" />
                  Export PDF
                </Button>
                <Button className="flex-1" asChild>
                  <Link href={`/student/lab/${selectedAttempt.id}`}>
                    <Eye className="w-4 h-4 mr-2" />
                    View in Lab
                  </Link>
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </main>
    </div>
  )
}
